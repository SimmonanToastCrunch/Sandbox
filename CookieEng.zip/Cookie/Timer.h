#pragma once
#include <SDL_timer.h>

typedef const Uint32 interval;

static Uint32 callback(Uint32 interv, void* param);

class Timer 
{
public:
	// 
	void start(interval time)
	{
		SDL_AddTimer(time, callback, this);
	}
	void stop()
	{
		SDL_RemoveTimer(timer_id);
	}

	SDL_TimerID timer_id{};

	// the function that will be called whenever this timer's timeout is complete. Must return an "interval" (typedef for const Uint32&). The returned value will be the new wait time after this timer is restarted. or the timer will not be restarted if it returns 0
	virtual interval onTimeout()
	{
		return 0;
	}

};

// this is the function called any time a timer's time is up. It will notify the timer object it originated from 
static Uint32 callback(Uint32 interv, void* param)
{
	Timer* timer = reinterpret_cast<Timer*>(param);
	interval return_val = timer->onTimeout();
	if (return_val > 0)
	{
		return return_val;
	}
	else
	{
		SDL_RemoveTimer(timer->timer_id);
		return 0;
	}
}