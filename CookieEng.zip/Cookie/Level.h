#pragma once
#include <map>

#include "Signal.h"
#include "Node.h"



class Level : public SignalController
{
public:
	typedef const float& delta_t;
	typedef const Signal& crSignal;

	// function that loops through all stored nodes and handles them
	void handle_all(delta_t delta);

	// allocates a new node on the heap, then returns a void pointer to the created node
	void link_node(Node* node);

	// removes a node from the hashmap
	void free_node(Node* node);

	// unload all nodes from memory
	void unload();

	// function that's called every frame
	virtual void onUpdate(delta_t delta)
	{

	}

	// function that's called upon this level being loaded into a game object
	virtual void onLoad()
	{

	}


	// hashmap storing values of nodes
	std::map<char, Node*> nodes;
	char next_val = 0;
};

