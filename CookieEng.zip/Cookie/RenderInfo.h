#pragma once
#include <iostream>
#include <SDL_image.h>

// a class storing various types of data needed when the game attempts to render a node. 
class RenderInfo
{
public:
	RenderInfo(SDL_Rect pos_dim = {0,0,1,1}, unsigned int pdegree = 0, SDL_RendererFlip flipped = SDL_RendererFlip::SDL_FLIP_NONE, SDL_Texture* ptexture = nullptr, SDL_Color pcolor = { 255,255,255,255 })
		: pos(pos_dim), degree(pdegree), flip(flipped), texture(ptexture), color_mod(pcolor)
	{}
	~RenderInfo()
	{
		SDL_DestroyTexture(texture);
	}

	SDL_Rect pos;
	unsigned int degree;
	SDL_RendererFlip flip;
	SDL_Texture* texture;
	SDL_Color color_mod;

	// loads a texture from disk and into memory, returning a pointer to the loaded SDL_Texture object
	SDL_Texture* load_texture(const char* path)
	{
		auto tex = IMG_LoadTexture(renderer, path);
		// print error message to console, 
		if (tex == NULL)
		{
			std::cout << "Failed to load texture into memory! Error: " << IMG_GetError() << ". Returning NULL!\n";
		}
		return tex;
	}

	static SDL_Renderer* renderer;
};