#pragma once

#include "Timer.h"

// an engine-provided class that inherits from timer. measures frame rate and provide delta time.
class FrameCounter : public Timer
{
public:
	FrameCounter()
		: accum(nullptr), frame(nullptr), delta(nullptr)
	{}

	interval onTimeout() override
	{
		// set the value of frame (fps) equal to the refresh rate (divided by 1000 to convert it to seconds instead of ms) 
		(*frame) = (*accum) / ((float)refresh_rate / 1000.f);
		(*delta) = (1.f) / (float)(*frame);
		// reset the value of accum
		(*accum) = 0;
		// return refresh rate to begin the timer again
		return refresh_rate;
	}

	// function that changes the address of how many frames have been rendered over the course of a second
	inline void set_accum(unsigned int* paccum)
	{
		accum = paccum;
	}
	// function that changes the address of where the fps should be stored
	inline void set_frame(unsigned int* pframe)
	{
		frame = pframe;
	}
	// function that changes the address of where the delta time should be stored
	inline void set_delta(float* pdelta)
	{
		delta = pdelta;
	}

	interval refresh_rate = 1000;

private:
	// accum : a pointer to the amount of frames that have been rendered
	// frame : a pointer to the what var should be set to the fps
	unsigned int* accum, *frame;
	float* delta;

};