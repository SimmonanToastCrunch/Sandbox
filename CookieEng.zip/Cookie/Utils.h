#pragma once
#include <SDL_keyboard.h>
  
namespace Utils
{
	// clamp a value within a certain threshold
	int clamp(int min, int max, int value);

}

namespace Input
{
	bool is_key_down(const SDL_Scancode& scancode);
}