#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <iostream>
#include <deque>
#include <iostream>
#include <sstream>

#include "FrameCounter.h"
#include "Level.h"


// currently level system is broken. fix later
//#include "Level.h"

class Game
{
public:
	// creates a window/rendering context.
	// \param title : title of the window
	// \param ww : width of the window
	// \param wh : height of the window
	// \param flags : flags to be used when creating window (there's many different potential flags, use SDL_WINDOW_xxx ) this parameter is set to 0 by default
	// \param vsync : whether or not to have vysnc enabled. this parameter is set to true by default
	Game(const char* ptitle, int ww, int wh, Uint32 flags = 0, bool vsync = true);
	// cleans SDL
	~Game();

	// setters
	inline void set_base_color(const SDL_Color& color) { SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a); }

	// getters
	inline const SDL_Color& get_base_color() const { return base_col; }

	// end of set/get

	// the ultimate encapsulation. Handles all sdl_events, linked objects, scenes, input, rendering, etc. etc.
	void handle_all();

	// function to be used in game loop. returns a const reference to avoid copying (though copying a byte size variable is negligible in performance)
	bool is_running() { return running; }

	// loads a level into memory
	void load(Level* plevel);

	SDL_Texture* load_texture(const char* ppath);

private:
	const char* title;

	SDL_Window* window;
	SDL_Renderer* renderer;

	// fps counter
	FrameCounter frame_counter;
	// integers used for the frame counter. accum is used to measure how many frames are able to be rendered before one second has passed
	unsigned int frame, accum;
	// delta time, used to get frame independent movement
	float delta;

	char bruh;

	// the currently loaded in level, while a level is loaded in, all of its "map members" will be rendered according to their onRender() function. they will also be handled by the map's "handle_all()" function
	Level* level = nullptr;
	//std::deque<Node*> nodes;


	// sdl event object used to poll events
	SDL_Event sdl_event{};
	// color used for the base draw color of the window
	SDL_Color base_col{};

	bool running = false;



	// The following functions are used for encapsulation

	// initializes SDL (with sdl_flags) and SDL_image (with img_flags)
	void init(Uint32 sdl_flags = SDL_INIT_EVERYTHING, Uint32 img_flags = IMG_INIT_PNG);

	// renders a node to the screen by calling the node's "on render" function
	// \returns true if render was successful, false if it failed (prints SDL_GetError() to console)
	bool render_node(Node* node)
	{
		// create a pointer to a new RenderInfo, to avoid using too much memory, and to avoid calling onRender() more than once
		RenderInfo* renderinfo = node->onRender(delta);
		// check to make sure that onRender is successful
		if (renderinfo == nullptr)
		{
			std::cout << "Cannot render node: " << node << " ! Error: node->onRender() returned nullptr" << std::endl;
			return false;
		}
		else
		{
			SDL_Point center = { renderinfo->pos.x, renderinfo->pos.y };
			if (SDL_RenderCopyEx(renderer, renderinfo->texture, NULL, &renderinfo->pos, renderinfo->degree, &center, renderinfo->flip) != 0)
			{
				std::cout << "Failed to render node: " << node << " ! Error: " << SDL_GetError() << std::endl;
			}
			else
			{
				return false;
			}
		}
		return false;
	}

};

