#include "Level.h"

void Level::handle_all(delta_t delta)
{
	if (!nodes.empty())
	{
		for (int i = nodes.size(); i != nodes.size(); i++)
		{
			nodes[i]->onUpdate(delta);
		}
	}
}

void Level::link_node(Node* node)
{
	// add pointer to new node to deque
	nodes[next_val] = node;
	// notify node that it's key has changed
	node->key = next_val;
	
	node->parent = this;
	// notify object
	node->onLink();
	next_val++;
}


void Level::free_node(Node* node)
{
	// delete the element at index[key]
	nodes.erase(node->key);
}


void Level::unload()
{
	nodes.clear();
}
