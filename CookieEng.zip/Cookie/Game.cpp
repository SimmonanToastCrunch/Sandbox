#include "Game.h"

Game::Game(const char* ptitle, int ww, int wh, Uint32 flags, bool vsync)
	: title(ptitle), delta(0.f)
{
	using namespace std;
	init();
	
	window = SDL_CreateWindow
	(
		title,
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		ww,
		wh,
		flags
	);
	if (!window)
	{
		cout << "Failed to create window! Error: " << SDL_GetError() << "\n";
	}

	renderer = SDL_CreateRenderer
	(
		window,
		-1,
		SDL_RENDERER_ACCELERATED |  (vsync ? SDL_RENDERER_PRESENTVSYNC : 0)
	);

	if (!renderer)
	{
		cout << "Failed to create rendering context! Error: " << SDL_GetError() << "\n";
	} 
	// set the static renderer object in every RenderInfo class to the renderer stored in this game object
	

	accum = 0;
	frame = 0;

	
	frame_counter.set_accum(&accum);
	frame_counter.set_frame(&frame);
	frame_counter.set_delta(&delta);
	frame_counter.start(frame_counter.refresh_rate);

	// game loop starts
	running = true;
	cout << endl;
}

// set the static renderer held in every RenderInfo class to the renderer stored in this game
SDL_Renderer* RenderInfo::renderer = renderer;

Game::~Game()
{
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
	std::cout << "SDL cleaned!\n";
}

void Game::handle_all()
{
	// set the memory of all the inputs to false, before we get the input for them.
	//memset(keys, false, sizeof(bool) * 50);

	SDL_RenderClear(renderer);

	while (SDL_PollEvent(&sdl_event))
	{
		switch (sdl_event.type)
		{
		case SDL_QUIT:
			running = false;
			break;
		default:
			break;
		}

	}

	if (level != nullptr)
	{
		level->handle_all(delta);

		if (!level->nodes.empty())
		{
			for (int i = 0; i != level->nodes.size(); i++)
			{
				// for every element in the map, render it!
				render_node(level->nodes[i]);

			}
		}
	}


	std::stringstream stream;
	stream << title << " - FPS: " << frame;

	SDL_SetWindowTitle(window, stream.str().c_str());

	SDL_RenderPresent(renderer);

	// all handling is done, therefore, accum can be incremented bc a frame has passed
	accum++;

}


void Game::load(Level* plevel)
{
	level = plevel;
	plevel->onLoad();
}

SDL_Texture* Game::load_texture(const char* ppath)
{
	auto tex = IMG_LoadTexture(renderer, ppath);
	return tex;
}



void Game::init(Uint32 sdl_flags, Uint32 img_flags)
{
	using namespace std;
	if (SDL_Init(sdl_flags) != NULL)
	{
		cout << "SDL failed to init! Error: " << SDL_GetError() << "\n";
	}
	if (IMG_Init(img_flags) == NULL)
	{
		cout << "SDL_image failed to init! Error: " << IMG_GetError() << "\n";
	}

}
#if 0
bool Game::render_node(Node* node)
{
	
}
#endif 