#pragma once
#include <sstream>

#include "Timer.h"

class FrameUpdate : public Timer
{
public:
	FrameUpdate(SDL_Window* pwindow, const char* ptitle)
		: title(ptitle), window(pwindow)
	{
		start(refresh_rate);
	}

	interval onTimeOut()
	{
		stream.clear();
		// after timeout, set the ostream equal to the title of the window + fps
		stream << title << " | FPS: " << (*frame);
		// set value of string equal to the stream data.
		SDL_SetWindowTitle(window, stream.str().c_str());
		// return refresh rate to reset timer.
		return refresh_rate;
	}

	unsigned int* frame = nullptr;

private:
	const interval refresh_rate = 1000;
	const char* title;
	SDL_Window* window;
	std::stringstream stream{};

};