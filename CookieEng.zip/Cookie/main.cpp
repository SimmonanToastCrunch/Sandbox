#include "Game.h"

int main(int argc, char* args[])
{
	Game game("Game", 1920, 1080);


	while (game.is_running())
	{
		game.handle_all();
	}


	return 0;
}