#include "Utils.h"

int Utils::clamp(int min, int max, int value)
{
	if (value > max)
	{
		value = max;
	}
	if (value < min)
	{
		value = min;
	}
	return value;
}

bool Input::is_key_down(const SDL_Scancode& scancode)
{
	auto keys = SDL_GetKeyboardState(0);
	return keys[scancode];
}
