#pragma once
#include "RenderInfo.h"
#include "Signal.h"

class Node
{
public:
	// typedef delta t to clean up code a tad
	typedef const float& delta_t;

	// function that will be called when this object is linked to a level
	virtual void onLink()
	{}

	// function that will be called every time it's linked game object is handled
	virtual void onUpdate(const float& delta)
	{
		std::cout << "Node updated!\n";
	}

	// function that will be called when this object is trying to be rendered. By default returns a nullptr, which won't be rendered.
	virtual RenderInfo* onRender(const float& delta)
	{
		std::cout << "Attempted to render node!\n";
		return nullptr;
	}

	void* emit_signal(crSignal signal)
	{
		if (parent == nullptr)
		{
			std::cout << "Cannot emit signal to a nullptr!\n";
			return nullptr;
		}
		else
		{
			return parent->onSignal(signal);
		}
	}

	char key = 0;
	SignalController* parent = nullptr;

};

