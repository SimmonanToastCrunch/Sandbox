#pragma once

class SignalController;
class Signal;

typedef const Signal& crSignal;

class Signal
{
public:
	Signal(const unsigned short& pid, void* const pparam)
		: id(pid), param(pparam)
	{}

	// user defined ID for this signal
	const unsigned short id;
	// user defined parameter, to pass whatever variables you'd like into the signal handler in the level
	void* const param;

};

class SignalController
{
public:
	// function that's called when a signal is recieved from a node
	// \param signal : 
	virtual void* onSignal(crSignal signal)
	{
		return nullptr;
	}


};