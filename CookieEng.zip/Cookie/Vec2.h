#pragma once

class Vec2
{
public:
	Vec2(int px, int py)
		: x(px), y(py)
	{}
	Vec2()
		: x(0), y(0)
	{}
	int x, y;

	void operator += (const Vec2& add)
	{
		this->x += add.x;
		this->y += add.y;
	}
	void operator -= (const Vec2& sub)
	{
		this->x -= sub.x;
		this->y -= sub.y;
	}

};