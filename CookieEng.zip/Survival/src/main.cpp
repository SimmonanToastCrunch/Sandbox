#include "Game.h"


int main(int argc, char* args[])
{
	Game* game = new Game("Survival", 1920, 1080);

	const Uint8 wind_col = 195;

	game->set_base_color({wind_col, wind_col, wind_col, 255});

	while (game->is_running())
	{
		game->handle_all();
	}

	return 0;
}